resolve: {
    fallback: {
      http: require.resolve('stream-http')
    }
  }
  