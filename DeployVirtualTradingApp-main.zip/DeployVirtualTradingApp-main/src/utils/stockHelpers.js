// // utils/stockHelpers.js
// export const getStockTypeFromSymbol = (symbol) => {
//     if (!symbol) return 'nifty50';
//     if (symbol.includes('.ETF') || symbol.includes('-ETF')) return 'etf';
//     if (symbol.length <= 4) return 'nifty50';
//     return 'nifty500';
//   };